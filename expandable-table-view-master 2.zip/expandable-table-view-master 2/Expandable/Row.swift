//
//  course.swift
//  JAF
//
//  Created by Conference on 5/8/17.
//  Copyright © 2017 Conference. All rights reserved.
//

import Foundation
public struct Row {
    public var name : String?
    public var pictureUrl : String?
    public var Description : String?
    public var cat_name : String?
    public var isExpandable : Bool!
    public var isSelectable : Bool!
    
    
    public static func modelsFromDictionaryArray(array:NSArray) -> [Row]
    {
        var models:[Row] = []
        for item in array
        {
            models.append(Row(dictionary: item as! NSDictionary)!)
        }
        return models
    }
     public init?(dictionary: NSDictionary) {
        
        name = dictionary["name"] as? String
        pictureUrl = dictionary["pictureUrl"] as? String
        Description = dictionary["Description"] as? String
        cat_name = dictionary["cat_name"] as? String
        isExpandable = true
        isSelectable = true
    }
    public func dictionaryRepresentation() -> NSDictionary {
        
        let dictionary = NSMutableDictionary()
        
        dictionary.setValue(self.name, forKey: "name")
        dictionary.setValue(self.pictureUrl, forKey: "pictureUrl")
        dictionary.setValue(self.Description, forKey: "Description")
        dictionary.setValue(self.cat_name, forKey: "cat_name")
        dictionary.setValue(self.isExpandable, forKey: "isExpandable")
        dictionary.setValue(self.isSelectable, forKey: "isSelectable")
        
        return dictionary
    }
    
}

