//
//  category.swift
//  JAF
//
//  Created by Conference on 5/8/17.
//  Copyright © 2017 Conference. All rights reserved.
//

import Foundation
public class Section {
    public var id : Int?
    public var fullName : String?
    public var pictureUrl : String?
    public var email : String?
    public var about : String?
    public var isCollapsible: Bool?
    public var isCollapsed: Bool?
    public var friends : Array<Row>?
    public class func modelsFromDictionaryArray(array:NSArray) -> [Section]
    {
        var models:[Section] = []
        for item in array
        {
            models.append(Section(dictionary: item as! NSDictionary)!)
        }
        return models
    }
    required public init?(dictionary: NSDictionary) {
        
        id = dictionary["id"] as? Int
        fullName = dictionary["fullName"] as? String
        pictureUrl = dictionary["pictureUrl"] as? String
        email = dictionary["email"] as? String
        about = dictionary["about"] as? String
        isCollapsible = true
        isCollapsed = true
        if (dictionary["friends"] != nil) {
            friends = Row.modelsFromDictionaryArray(array: dictionary["friends"] as! NSArray)
        }
    }
    public func dictionaryRepresentation() -> NSDictionary {
        
        let dictionary = NSMutableDictionary()
        
        dictionary.setValue(self.id, forKey: "id")
        dictionary.setValue(self.fullName, forKey: "fullName")
        dictionary.setValue(self.pictureUrl, forKey: "pictureUrl")
        dictionary.setValue(self.email, forKey: "email")
        dictionary.setValue(self.about, forKey: "about")
        dictionary.setValue(self.isCollapsible, forKey: "isCollapsible")
        dictionary.setValue(self.isCollapsed, forKey: "isCollapsed")
       
        return dictionary
    }
    
}

