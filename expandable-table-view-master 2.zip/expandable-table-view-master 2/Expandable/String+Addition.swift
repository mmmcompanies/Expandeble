//
//  String+Addition.swift

import Foundation
//http://stackoverflow.com/questions/25818197/how-to-split-a-string-in-swift

  
extension String {
    func localized() ->String {
        
        let selLang = appDelObj.currentLang
        let path = Bundle.main.path(forResource: selLang, ofType: "lproj")
        
        let bundle = Bundle(path: path!)
        return NSLocalizedString(self, tableName: nil, bundle: bundle!, value: "", comment: "")
    }
func split(regexpattern: Character) -> [String] {
        
        return self.characters.split{$0 == regexpattern}.map(String.init)
    }
    
}
