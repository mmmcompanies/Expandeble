//
//  ViewController.swift
//  Expandable
//
//  Created by Gabriel Theodoropoulos on 28/10/15.
//  Copyright © 2015 Appcoda. All rights reserved.
//

import UIKit
import MessageUI

let appDelObj = UIApplication.shared.delegate as! AppDelegate

class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource, CustomCellDelegate , MFMailComposeViewControllerDelegate {

    // MARK: IBOutlet Properties
    
    @IBOutlet weak var buttonSend: UIButton!
    @IBOutlet weak var tblExpandable: UITableView!
     var reloadSections: ((_ section: Int) -> Void)?
    
    var sectionArray:[Section] = []
    

    fileprivate let viewModel = ProfileViewModel()
    var items = itemsAgain
        // MARK: Variables
    var indexPathForUpdateRow:IndexPath?
    var cellDescriptors: NSMutableArray!
    var count = 0
    var visibleRowsPerSection = [[Int]]()
    var insert = false
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        
        let url = Bundle.main.url(forResource: "TableData", withExtension: "json")
         do {
       let data = try Data(contentsOf: url!)
    
            do {
                let object = try JSONSerialization.jsonObject(with: data, options: .allowFragments)
                if let dictionary = object as? [String: AnyObject] {
                    let body = dictionary["data"] as? NSArray
                    let temp = Section.modelsFromDictionaryArray(array: body!)
                    self.sectionArray = temp
                }
            } catch {
                print("Error deserializing JSON: \(error)")
            }
         }
         catch {
            print("Error deserializing JSON: \(error)")
            
        }
        
        
        
       
//            if let json = try JSONSerialization.jsonObject(with: data!) as? NSArray, let body = json.value(forKey: "Data") as? NSArray
//            {
//                let temp = Section.modelsFromDictionaryArray(array: body)
//                self.sectionArray = temp
//            }
        
        
       reloadSections = { [weak self] (section: Int) in
            self?.tblExpandable?.beginUpdates()
            self?.tblExpandable?.reloadSections([section], with: .fade)
//        self?.tblExpandable?.reloadData()
            self?.tblExpandable?.endUpdates()
        }

    }

    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        setLocalization()
        configureTableView()
        
        loadCellDescriptors()
//        print(cellDescriptors)
    }
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    @IBAction func sendMailClicked(_ sender: Any) {
        
        
        let mainStoryBoard = UIStoryboard(name: "Main", bundle: nil)
        let leftMenu = mainStoryBoard.instantiateViewController(withIdentifier:"NextViewController") as! NextViewController
//        appDelObj.window?.rootViewController = leftMenu
//        appDelObj.window?.makeKeyAndVisible()
        self.navigationController?.pushViewController(leftMenu, animated: true)
        
//        let mailComposeViewController = configuredMailComposeViewController()
//        if MFMailComposeViewController.canSendMail() {
//            self.present(mailComposeViewController, animated: true, completion: nil)
//        } else {
////            self.showSendMailErrorAlert()
//            
//            let path = Bundle.main.path(forResource: appDelObj.currentLang, ofType: "lproj")
//            let bundle = Bundle(path: path!)
//            
//            
//
//        }
        
        
    }
    @IBAction func languageButtonClicked(_ sender: UIButton) {
        
        let tagButton = sender.tag
        switch tagButton {
        case 1:
            
            appDelObj.currentLang = "en"
            UserDefaults.standard.set("en", forKey: "currentLang")
            setLocalization()

            break
        case 2:
            
            appDelObj.currentLang = "fr"
            UserDefaults.standard.set("fr", forKey: "currentLang")
            setLocalization()
            break
        case 3:
            
            appDelObj.currentLang = "de"
            UserDefaults.standard.set("de", forKey: "currentLang")
            setLocalization()
            break
            
        default:
            break
            
        }
        
    }
    
    func setLocalization(){
    
        buttonSend.setTitle("SendMail".localized(), for: .normal)
    
    }
    
    func setViewController(){
    
        let path = Bundle.main.path(forResource: appDelObj.currentLang, ofType: "lproj")
        _ = Bundle(path: path!)
        
        let mainStoryBoard = UIStoryboard(name: "Main", bundle: nil)
        let leftMenu = mainStoryBoard.instantiateViewController(withIdentifier:"ViewController") as! ViewController
        appDelObj.window?.rootViewController = leftMenu
        appDelObj.window?.makeKeyAndVisible()
    
    }
    
    func configuredMailComposeViewController() -> MFMailComposeViewController {
        let mailComposerVC = MFMailComposeViewController()
        mailComposerVC.mailComposeDelegate = self // Extremely important to set the --mailComposeDelegate-- property, NOT the --delegate-- property
        
        mailComposerVC.setToRecipients(["balkaran_maan@yahoo.com","madankumawat.ios@yahoo.com"])
        mailComposerVC.setSubject("Sending you an in-app e-mail...")
        mailComposerVC.setMessageBody("Sending e-mail in-app is not so bad!", isHTML: false)
        
        return mailComposerVC
    }
    
    func showSendMailErrorAlert() {
//        let sendMailErrorAlert = UIAlertView(title: "Could Not Send Email", message: "Your device could not send e-mail.  Please check e-mail configuration and try again.", delegate: self, cancelButtonTitle: "OK")
//        sendMailErrorAlert.show()
    }
    
    // MARK: MFMailComposeViewControllerDelegate Method
    func mailComposeController(_ controller: MFMailComposeViewController, didFinishWith result: MFMailComposeResult, error: Error?) {
        controller.dismiss(animated: true, completion: nil)
    }
    
    // MARK: Custom Functions
    
    func configureTableView() {
        
        tblExpandable.delegate = self
        tblExpandable.dataSource = self
        tblExpandable?.sectionHeaderHeight = 70
        tblExpandable?.estimatedRowHeight = 100
        tblExpandable?.rowHeight = UITableViewAutomaticDimension
        
        tblExpandable.register(UINib(nibName: "YNExpandableCellEx", bundle: Bundle.main), forCellReuseIdentifier: "YNExpandableCellEx")
        tblExpandable.register(UINib(nibName: "WorklistItemCell", bundle: Bundle.main), forCellReuseIdentifier: "WorklistItemCell")
        
         tblExpandable?.register(HeaderView.nib, forHeaderFooterViewReuseIdentifier: HeaderView.identifier)
    }

    
    func loadCellDescriptors() {
        if let path = Bundle.main.path(forResource: "CellDescriptor", ofType: "plist") {
            cellDescriptors = NSMutableArray(contentsOfFile: path)
            getIndicesOfVisibleRows()
            tblExpandable.reloadData()
        }
    }
    
    
    func getIndicesOfVisibleRows() {
        visibleRowsPerSection.removeAll()
        
        for currentSectionCells in cellDescriptors {
            print(currentSectionCells)
            var visibleRows = [Int]()
            
            for row in 0...((currentSectionCells as AnyObject).count - 1) {
                
                if (currentSectionCells as AnyObject).objectAt(row)["isVisible"] as! Bool == true {
                    visibleRows.append(row)
                }
            }
            
            visibleRowsPerSection.append(visibleRows)
        }
    }
    
    
    func getCellDescriptorForIndexPath(_ indexPath: IndexPath) -> [String: AnyObject] {
        let indexOfVisibleRow = visibleRowsPerSection[indexPath.section][indexPath.row]
        
        let cellDescriptor = (cellDescriptors[indexPath.section] as! NSMutableArray)[indexOfVisibleRow] as! [String: AnyObject]
        return cellDescriptor
    }
    
    
    // MARK: UITableView Delegate and Datasource Functions
    
//    func numberOfSections(in tableView: UITableView) -> Int {
//       return items.count
//    }
//    
//    
//    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
//        return visibleRowsPerSection[section].count
//    }
//    
//    
//    func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
//        switch section {
//        case 0:
//            return "Personal"
//            
//        case 1:
//            return "Preferences"
//            
//        default:
//            return "Work Experience"
//        }
//    }
    
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return sectionArray.count
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        let item = sectionArray[section]
        guard item.isCollapsible! else {
            return sectionArray[section].friends!.count
        }
        if item.isCollapsed! {
            return 0
        }
        else {
            return sectionArray[section].friends!.count
        }
    }
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        if let headerView = tableView.dequeueReusableHeaderFooterView(withIdentifier: HeaderView.identifier) as? HeaderView {
            
            headerView.section = section
            let item = sectionArray
            headerView.item = item
            headerView.delegate = self
            return headerView
            
        }
        return UIView()
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let boolValue = sectionArray[indexPath.section].friends?[indexPath.row].isSelectable
        if boolValue!{
        let cell = tableView.dequeueReusableCell(withIdentifier: YNExpandableCellEx.ID, for: indexPath) as! YNExpandableCellEx
            
            cell.titleLabel.text = sectionArray[indexPath.section].friends?[indexPath.row].name
            
            cell.selectionStyle = UITableViewCellSelectionStyle.none
            return cell
        }
        else
        {
            let cell = tableView.dequeueReusableCell(withIdentifier: YNExpandableCellEx.ID, for: indexPath) as! YNExpandableCellEx
            
            cell.titleLabel.text = sectionArray[indexPath.section].friends?[indexPath.row].Description
            
            cell.selectionStyle = UITableViewCellSelectionStyle.none
            return cell

        }
    }
    
    
//    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
//        
//            return 50.0
//            
//    }
    
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        indexPathForUpdateRow = indexPath
         print((sectionArray[indexPath.section].friends?[indexPath.row].isSelectable)!)
        
        let boolValue = sectionArray[indexPath.section].friends?[indexPath.row].isSelectable
        if boolValue! {
            
            let Value = sectionArray[indexPath.section].friends?[indexPath.row].isExpandable
             if Value! {
                
                sectionArray[indexPath.section].friends?[indexPath.row].isExpandable = false
                
                let friend = (sectionArray[indexPath.section].friends?[indexPath.row])!
                sectionArray[indexPath.section].friends?.insert(friend, at: indexPath.row + 1)
                
                sectionArray[indexPath.section].friends?[indexPath.row + 1].isSelectable = false
                sectionArray[indexPath.section].friends?[indexPath.row].isSelectable = true
                sectionArray[indexPath.section].friends?[indexPath.row + 1].name = "Hello I am "
                print((sectionArray[indexPath.section].friends?[indexPath.row].isSelectable)!)
                print((sectionArray[indexPath.section].friends?[indexPath.row + 1].isSelectable)!)
                
                
                tblExpandable?.beginUpdates()
                let section = indexPath.section
                let IndexPathOfLastRow = IndexPath(row: (indexPath.row + 1) , section: section)
                
                self.tblExpandable.insertRows(at: [IndexPathOfLastRow], with: UITableViewRowAnimation.fade)
                tblExpandable?.endUpdates()
                
             } else{
                
                sectionArray[indexPath.section].friends?[indexPath.row].isExpandable = true
                
                sectionArray[indexPath.section].friends?.remove(at: indexPath.row + 1)
                
                tblExpandable?.beginUpdates()
                let section = indexPath.section
                let IndexPathOfLastRow = IndexPath(row: (indexPath.row + 1) , section: section)
                
                self.tblExpandable.deleteRows(at: [IndexPathOfLastRow], with: UITableViewRowAnimation.fade)
                tblExpandable?.endUpdates()
                
            }
        }
            
        else{
        }
        
        
        
        
//        let indexOfTappedRow = visibleRowsPerSection[indexPath.section][indexPath.row]
//   //  (cellDescriptors[indexPath.section] as! NSMutableArray)[indexOfVisibleRow] as! [String: AnyObject]
//        if (cellDescriptors[indexPath.section] as! [[String: AnyObject]])[indexOfTappedRow] ["isExpandable"] as! Bool == true {
//            var shouldExpandAndShowSubRows = false
//            if (cellDescriptors[indexPath.section] as! [[String: AnyObject]])[indexOfTappedRow]["isExpanded"] as! Bool == false {
//                // In this case the cell should expand.
//                shouldExpandAndShowSubRows = true
//            }
//            
//            ((cellDescriptors[indexPath.section] as! NSMutableArray)[indexOfTappedRow] as AnyObject).setValue(shouldExpandAndShowSubRows, forKey: "isExpanded")
//            
//            for i in (indexOfTappedRow + 1)...(indexOfTappedRow + ((cellDescriptors[indexPath.section]  as! [[String: AnyObject]])[indexOfTappedRow]["additionalRows"] as! Int)) {
//                ((cellDescriptors[indexPath.section]  as! NSMutableArray)[i] as AnyObject).setValue(shouldExpandAndShowSubRows, forKey: "isVisible")
//            }
//        }
//        else {
//            if (cellDescriptors[indexPath.section] as! [[String: AnyObject]])[indexOfTappedRow]["cellIdentifier"] as! String == "idCellValuePicker" {
//                var indexOfParentCell: Int!
//             /*   for var i = 10; i > 0; i-- {
//                    print(i)
//                }
//                
//                // use this
//                for i in (1...10).reverse() {
//                    
//                    */
//                for i in (0...indexOfTappedRow - 1).reversed(){
//             //   for var i=indexOfTappedRow - 1; i>=0; i -= 1 {
//                    if (cellDescriptors[indexPath.section] as! [[String: AnyObject]])[i]["isExpandable"] as! Bool == true {
//                        indexOfParentCell = i
//                        break
//                    }
//                }
//                
//                ((cellDescriptors[indexPath.section] as! NSMutableArray)[indexOfParentCell] as AnyObject).setValue((tblExpandable.cellForRow(at: indexPath) as! CustomCell).textLabel?.text, forKey: "primaryTitle")
//                ((cellDescriptors[indexPath.section] as! NSMutableArray)[indexOfParentCell] as AnyObject).setValue(false, forKey: "isExpanded")
//                
//                for i in (indexOfParentCell + 1)...(indexOfParentCell + ((cellDescriptors[indexPath.section]  as! [[String: AnyObject]])[indexOfParentCell]["additionalRows"] as! Int)) {
//                    ((cellDescriptors[indexPath.section]   as! NSMutableArray)[i] as AnyObject).setValue(false, forKey: "isVisible")
//                }
//            }
//        }
//        
//        getIndicesOfVisibleRows()
//        self.tblExpandable?.beginUpdates()
//        tblExpandable.reloadSections(IndexSet(integer: indexPath.section), with: UITableViewRowAnimation.fade)
//         self.tblExpandable?.endUpdates()
    }
    
    
    // MARK: CustomCellDelegate Functions
    
    func dateWasSelected(_ selectedDateString: String) {
        let dateCellSection = 0
        let dateCellRow = 3
        
        ((cellDescriptors[dateCellSection] as! NSMutableArray)[dateCellRow] as AnyObject).setValue(selectedDateString, forKey: "primaryTitle")
        tblExpandable.reloadData()
    }
    
    
    func maritalStatusSwitchChangedState(_ isOn: Bool) {
        let maritalSwitchCellSection = 0
        let maritalSwitchCellRow = 6
        
        let valueToStore = (isOn) ? "true" : "false"
        let valueToDisplay = (isOn) ? "Married" : "Single"
 
        ((cellDescriptors[maritalSwitchCellSection] as! NSMutableArray)[maritalSwitchCellRow] as AnyObject).setValue(valueToStore, forKey: "value")
        ((cellDescriptors[maritalSwitchCellSection] as! NSMutableArray)[maritalSwitchCellRow - 1] as AnyObject).setValue(valueToDisplay, forKey: "primaryTitle")
        tblExpandable.reloadData()
    }
    
    
    func textfieldTextWasChanged(_ newText: String, parentCell: CustomCell) {
        let parentCellIndexPath = tblExpandable.indexPath(for: parentCell)
        
            let currentFullname = ((cellDescriptors[0] as! NSMutableArray)[0] as AnyObject)["primaryTitle"] as! String
        let fullnameParts = currentFullname.components(separatedBy: " ")
        
        var newFullname = ""
        
        if parentCellIndexPath?.row == 1 {
            if fullnameParts.count == 2 {
                newFullname = "\(newText) \(fullnameParts[1])"
            }
            else {
                newFullname = newText
            }
        }
        else {
            newFullname = "\(fullnameParts[0]) \(newText)"
        }
        
       ((cellDescriptors[0] as! NSMutableArray)[0] as AnyObject).setValue(newFullname, forKey: "primaryTitle")
        tblExpandable.reloadData()
    }
    
    
    func sliderDidChangeValue(_ newSliderValue: String) {
        ((cellDescriptors[2] as! NSMutableArray)[0] as AnyObject).setValue(newSliderValue, forKey: "primaryTitle")
        ((cellDescriptors[2] as! NSMutableArray)[1] as AnyObject).setValue(newSliderValue, forKey: "value")
        
        if !insert {
        insert = true
        tblExpandable?.beginUpdates()
//        tblExpandable.reloadRows(at: [indexPathForUpdateRow!],  with: UITableViewRowAnimation.none)
        
        let section = indexPathForUpdateRow?.section
        
        let IndexPathOfLastRow = IndexPath(row: visibleRowsPerSection[section!].count - 1 , section: section!)
        
        self.tblExpandable.insertRows(at: [IndexPathOfLastRow], with: UITableViewRowAnimation.fade)
        
         ((cellDescriptors[section!] as! NSMutableArray)[2] as AnyObject).setValue(true, forKey: "isExpanded")
        ((cellDescriptors[section!]  as! NSMutableArray)[2] as AnyObject).setValue(true, forKey: "isVisible")
        getIndicesOfVisibleRows()
        tblExpandable?.endUpdates()
    }
    }
    
}

extension ViewController: HeaderViewDelegate {
    func toggleSection(header: HeaderView, section: Int) {
        var item = sectionArray[section]
        if item.isCollapsible! {
            
            // Toggle collapse
            let collapsed = !item.isCollapsed!
            item.isCollapsed = collapsed
            header.setCollapsed(collapsed: collapsed)
            
            // Adjust the number of the rows inside the section
            reloadSections?(section)
        }
    }
}


//extension ViewController: UITableViewDataSource {
//    func numberOfSections(in tableView: UITableView) -> Int {
//        return items.count
//    }
//
//    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
//        let item = items[section]
//        guard item.isCollapsible else {
//            return item.rowCount
//        }
//
//        if item.isCollapsed {
//            return 0
//        } else {
//            return item.rowCount
//        }
//    }
//
//}
//
//extension ViewController: UITableViewDelegate {
//    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
//        if let headerView = tableView.dequeueReusableHeaderFooterView(withIdentifier: HeaderView.identifier) as? HeaderView {
//            let item = items[section]
//
//            headerView.item = item
//            headerView.section = section
//            headerView.delegate = self
//            return headerView
//        }
//        return UIView()
//    }
//}
