
import UIKit

class YNExpandableCellEx: UITableViewCell {
    static let ID = "YNExpandableCellEx"
    
    @IBOutlet var titleLabel: UILabel!
    @IBOutlet weak var SeprtoreLineView: UIView!
    
    public override init(style: UITableViewCellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
    }
    
    required public init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        
    }
    
    public override func awakeFromNib() {
        super.awakeFromNib()
        
    }
}


class WorklistItemCell: UITableViewCell {
    static let ID = "WorklistItemCell"
    
    @IBOutlet weak var worklistDescriptionTxtView : UITextView!
    @IBOutlet weak var workListDescriptionLabel: UILabel!
    
    public override init(style: UITableViewCellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        
    }
    
    required public init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
    }
    
    public override func awakeFromNib() {
        super.awakeFromNib()
        self.selectionStyle = .none
        
    }
    
}

